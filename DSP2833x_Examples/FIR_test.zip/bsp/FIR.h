/*
 * FIR.h
 *
 *  Created on: 2023��1��12��
 *      Author: yang
 */

#ifndef APP_FIR_H_
#define APP_FIR_H_

#include "DSP28x_Project.h"
#include <stdio.h>
#include <string.h>

void FIR_Init(void);
void FIR_filter_run(void);


#endif /* APP_FIR_H_ */
